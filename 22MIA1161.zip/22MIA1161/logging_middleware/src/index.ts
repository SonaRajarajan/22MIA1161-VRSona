/**
 * @file index.ts
 * @description Reusable structured logging middleware for the AffordMed campus notification platform.
 *              Sends structured log entries to the AffordMed evaluation server.
 *
 * Usage:
 *   import { Log } from '@22mia1161/logging-middleware';
 *   Log("backend", "info", "controller", "Fetching notifications for student");
 */

import axios, { AxiosInstance } from "axios";

// ─── Type Definitions ────────────────────────────────────────────────────────

export type Stack = "backend" | "frontend";

export type Level = "debug" | "info" | "warn" | "error" | "fatal";

export type BackendPackage =
  | "cache"
  | "controller"
  | "cron_job"
  | "db"
  | "domain"
  | "handler"
  | "repository"
  | "service"
  | "state"
  | "style";

export type SharedPackage = "auth" | "config" | "middleware" | "utils";

export type FrontendPackage = "component" | "hook" | "page" | "state" | "style";

export type Package = BackendPackage | SharedPackage | FrontendPackage;

export interface LogPayload {
  stack: Stack;
  level: Level;
  package: Package;
  message: string;
}

export interface LogResponse {
  logID: string;
  message: string;
}

export interface LoggerConfig {
  /** AffordMed evaluation server base URL */
  baseURL: string;
  /** Bearer token obtained from /evaluation-service/auth */
  accessToken: string;
  /** Whether to also emit logs to the browser/node console (default: true) */
  consoleEcho?: boolean;
}

// ─── Internal Singleton State ─────────────────────────────────────────────────

let _httpClient: AxiosInstance | null = null;
let _config: LoggerConfig | null = null;

/**
 * Initialise the logger. Must be called ONCE at application startup before
 * using Log(). Subsequent calls update the configuration.
 */
export function initLogger(config: LoggerConfig): void {
  _config = { consoleEcho: true, ...config };

  _httpClient = axios.create({
    baseURL: config.baseURL,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${config.accessToken}`,
    },
    timeout: 5000,
  });
}

// ─── Core Log Function ────────────────────────────────────────────────────────

/**
 * Send a structured log entry to the AffordMed evaluation server.
 *
 * @param stack   - "backend" | "frontend"
 * @param level   - "debug" | "info" | "warn" | "error" | "fatal"
 * @param package - e.g. "controller", "db", "middleware", "utils"
 * @param message - Human-readable description of what happened at this point
 * @returns       Promise resolving to the server's LogResponse (fire-and-forget safe)
 *
 * @example
 * Log("backend", "info", "controller", "GET /notifications called for student 1042");
 * Log("backend", "error", "db", "Critical database connection failure.");
 * Log("frontend", "warn", "component", "Notification list rendered with 0 items");
 */
export async function Log(
  stack: Stack,
  level: Level,
  pkg: Package,
  message: string
): Promise<LogResponse | null> {
  if (!_httpClient || !_config) {
    // Fail silently if not initialised — never crash the host application
    console.warn("[Logger] initLogger() was not called before Log().");
    return null;
  }

  const payload: LogPayload = { stack, level, package: pkg, message };

  // Optional console echo for local development visibility
  if (_config.consoleEcho) {
    const ts = new Date().toISOString();
    const prefix = `[${ts}] [${stack.toUpperCase()}] [${level.toUpperCase()}] [${pkg}]`;
    if (level === "fatal" || level === "error") {
      console.error(`${prefix} ${message}`);
    } else if (level === "warn") {
      console.warn(`${prefix} ${message}`);
    } else {
      console.log(`${prefix} ${message}`);
    }
  }

  try {
    const response = await _httpClient.post<LogResponse>(
      "/evaluation-service/logs",
      payload
    );
    return response.data;
  } catch (err: unknown) {
    // Never let a logging failure crash the host application
    if (_config.consoleEcho) {
      console.error("[Logger] Failed to send log to server:", err);
    }
    return null;
  }
}

// ─── Convenience Shorthand Helpers ───────────────────────────────────────────

/** Log at DEBUG level */
export const logDebug = (stack: Stack, pkg: Package, message: string) =>
  Log(stack, "debug", pkg, message);

/** Log at INFO level */
export const logInfo = (stack: Stack, pkg: Package, message: string) =>
  Log(stack, "info", pkg, message);

/** Log at WARN level */
export const logWarn = (stack: Stack, pkg: Package, message: string) =>
  Log(stack, "warn", pkg, message);

/** Log at ERROR level */
export const logError = (stack: Stack, pkg: Package, message: string) =>
  Log(stack, "error", pkg, message);

/** Log at FATAL level */
export const logFatal = (stack: Stack, pkg: Package, message: string) =>
  Log(stack, "fatal", pkg, message);

export default Log;
