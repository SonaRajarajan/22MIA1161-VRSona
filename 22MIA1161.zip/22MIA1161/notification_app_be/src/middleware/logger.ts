/**
 * @file middleware/logger.ts
 * @description Re-exports the logging middleware functions initialised with
 *              the AffordMed evaluation server credentials from config.
 *
 *              Import { Log } from here throughout the backend to ensure
 *              all log calls are routed through the initialised singleton.
 */

import { initLogger, Log as _Log, logInfo, logWarn, logError, logFatal, logDebug } from "../../../logging_middleware/src/index";
import { config } from "../config";

// Initialise once on module load
initLogger({
  baseURL: config.affordmed.baseURL,
  accessToken: config.affordmed.accessToken,
  consoleEcho: config.server.nodeEnv === "development",
});

export { _Log as Log, logInfo, logWarn, logError, logFatal, logDebug };
