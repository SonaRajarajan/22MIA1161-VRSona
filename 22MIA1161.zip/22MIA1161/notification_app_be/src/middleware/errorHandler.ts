/**
 * @file middleware/errorHandler.ts
 * @description Global Express error handling middleware.
 *              Catches all unhandled errors, logs them, and returns a clean JSON response.
 */

import { Request, Response, NextFunction } from "express";
import { Log } from "./logger";

export interface AppError extends Error {
  statusCode?: number;
  code?: string;
}

export function errorHandler(
  err: AppError,
  req: Request,
  res: Response,
  _next: NextFunction
): void {
  const statusCode = err.statusCode ?? 500;
  const code = err.code ?? "INTERNAL_SERVER_ERROR";

  Log("backend", "error", "handler",
    `${req.method} ${req.path} → ${statusCode} ${code}: ${err.message}`
  );

  res.status(statusCode).json({
    success: false,
    error: {
      code,
      message: err.message ?? "An unexpected error occurred",
    },
  });
}

export function notFoundHandler(req: Request, res: Response): void {
  Log("backend", "warn", "handler", `404 — Route not found: ${req.method} ${req.path}`);

  res.status(404).json({
    success: false,
    error: {
      code: "NOT_FOUND",
      message: `Route ${req.method} ${req.path} not found`,
    },
  });
}
