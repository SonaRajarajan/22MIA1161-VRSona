/**
 * @file routes/notificationRoutes.ts
 * @description Express router for the notification API endpoints.
 */

import { Router } from "express";
import {
  getAllNotifications,
  getPriorityNotifications,
} from "../controller/notificationController";
import { Log } from "../middleware/logger";

const router = Router();

// Request logging middleware for all notification routes
router.use((req, _res, next) => {
  Log("backend", "debug", "middleware",
    `Inbound request — ${req.method} ${req.baseUrl}${req.path}`
  );
  next();
});

// GET /api/v1/notifications/priority  ← must be before /:id to avoid conflict
router.get("/priority", getPriorityNotifications);

// GET /api/v1/notifications
router.get("/", getAllNotifications);

export default router;
