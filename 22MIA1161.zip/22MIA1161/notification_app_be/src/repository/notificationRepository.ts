/**
 * @file repository/notificationRepository.ts
 * @description Data access layer. Fetches notifications from the AffordMed
 *              evaluation server API and returns typed domain objects.
 */

import axios, { AxiosInstance } from "axios";
import { Notification } from "../domain/types";
import { Log } from "../middleware/logger";
import { config } from "../config";

interface AffordMedNotificationsResponse {
  notifications: Notification[];
}

class NotificationRepository {
  private readonly client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: config.affordmed.baseURL,
      headers: {
        Authorization: `Bearer ${config.affordmed.accessToken}`,
        "Content-Type": "application/json",
      },
      timeout: 8000,
    });

    Log("backend", "info", "repository", "NotificationRepository initialised with AffordMed client");
  }

  /**
   * Fetch all notifications from the AffordMed evaluation server.
   * Supports optional type filtering via query param.
   */
  async fetchAll(typeFilter?: string): Promise<Notification[]> {
    Log("backend", "info", "repository",
      `fetchAll called — typeFilter=${typeFilter ?? "none"}`
    );

    try {
      const params: Record<string, string> = {};
      if (typeFilter) params.type = typeFilter;

      const response = await this.client.get<AffordMedNotificationsResponse>(
        "/evaluation-service/notifications",
        { params }
      );

      const notifications = response.data.notifications ?? [];
      Log("backend", "info", "repository",
        `fetchAll success — received ${notifications.length} notifications from AffordMed API`
      );

      return notifications;
    } catch (err: unknown) {
      Log("backend", "error", "repository",
        `fetchAll failed — ${err instanceof Error ? err.message : String(err)}`
      );
      throw err;
    }
  }
}

// Export singleton instance
export const notificationRepository = new NotificationRepository();
