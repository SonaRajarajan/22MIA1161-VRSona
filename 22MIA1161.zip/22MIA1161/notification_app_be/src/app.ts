/**
 * @file app.ts
 * @description Express application factory. Sets up middleware, routes, and error handlers.
 */

import express, { Application } from "express";
import cors from "cors";
import morgan from "morgan";
import notificationRoutes from "./routes/notificationRoutes";
import { errorHandler, notFoundHandler } from "./middleware/errorHandler";
import { Log } from "./middleware/logger";
import { config } from "./config";

export function createApp(): Application {
  const app = express();

  // ── Core Middleware ────────────────────────────────────────────────────────
  app.use(cors({
    origin: config.server.allowedOrigin,
    methods: ["GET", "PATCH", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
  }));

  app.use(express.json());

  // HTTP access log — only in development
  if (config.server.nodeEnv === "development") {
    app.use(morgan("dev"));
  }

  // ── Health Check ───────────────────────────────────────────────────────────
  app.get("/health", (_req, res) => {
    Log("backend", "debug", "controller", "Health check called");
    res.json({ status: "ok", service: "notification-app-be", timestamp: new Date().toISOString() });
  });

  // ── API Routes ─────────────────────────────────────────────────────────────
  app.use("/api/v1/notifications", notificationRoutes);

  // ── Error Handling ─────────────────────────────────────────────────────────
  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
