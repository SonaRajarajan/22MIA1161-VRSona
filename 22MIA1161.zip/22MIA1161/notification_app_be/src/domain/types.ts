/**
 * @file domain/types.ts
 * @description Core domain types for the campus notification platform.
 */

export type NotificationType = "Placement" | "Event" | "Result";

export interface Notification {
  ID: string;
  Type: NotificationType;
  Message: string;
  Timestamp: string;
}

export interface PrioritisedNotification extends Notification {
  /** Computed priority score — higher = more important */
  priorityScore: number;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
  };
}

// Type weights for priority scoring: Placement > Result > Event
export const TYPE_WEIGHTS: Record<NotificationType, number> = {
  Placement: 3,
  Result: 2,
  Event: 1,
};

/** Recency decay factor — higher = faster decay with time */
export const DECAY_FACTOR = 0.05;
