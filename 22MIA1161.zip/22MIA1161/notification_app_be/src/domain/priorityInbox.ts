/**
 * @file domain/priorityInbox.ts
 * @description Stage 6 — Priority Inbox algorithm.
 *
 * Computes the top-N notifications ranked by a weighted priority score
 * that combines notification type importance and recency.
 *
 * Score formula:
 *   priorityScore = typeWeight × (1 / (1 + hoursAgo × DECAY_FACTOR))
 *
 * Type weights: Placement=3, Result=2, Event=1
 *
 * Uses a min-heap of size N for O(M log N) time complexity —
 * significantly faster than sorting all M notifications when M >> N.
 */

import { Notification, PrioritisedNotification, TYPE_WEIGHTS, DECAY_FACTOR } from "./types";
import { Log } from "../middleware/logger";

// ─── Priority Score Computation ───────────────────────────────────────────────

/**
 * Compute the priority score for a notification.
 * Higher score = should appear closer to the top of the priority inbox.
 */
export function computePriorityScore(notification: Notification): number {
  const typeWeight = TYPE_WEIGHTS[notification.Type] ?? 1;
  const ageMs = Date.now() - new Date(notification.Timestamp).getTime();
  const hoursAgo = ageMs / (1000 * 60 * 60);
  return typeWeight * (1 / (1 + hoursAgo * DECAY_FACTOR));
}

// ─── Min-Heap Implementation ──────────────────────────────────────────────────

class MinHeap {
  private heap: PrioritisedNotification[] = [];
  private readonly capacity: number;

  constructor(capacity: number) {
    this.capacity = capacity;
  }

  private parent(i: number): number { return Math.floor((i - 1) / 2); }
  private left(i: number): number { return 2 * i + 1; }
  private right(i: number): number { return 2 * i + 2; }

  private swap(i: number, j: number): void {
    [this.heap[i], this.heap[j]] = [this.heap[j], this.heap[i]];
  }

  private bubbleUp(i: number): void {
    while (i > 0 && this.heap[this.parent(i)].priorityScore > this.heap[i].priorityScore) {
      this.swap(i, this.parent(i));
      i = this.parent(i);
    }
  }

  private sinkDown(i: number): void {
    let smallest = i;
    const l = this.left(i);
    const r = this.right(i);
    if (l < this.heap.length && this.heap[l].priorityScore < this.heap[smallest].priorityScore) {
      smallest = l;
    }
    if (r < this.heap.length && this.heap[r].priorityScore < this.heap[smallest].priorityScore) {
      smallest = r;
    }
    if (smallest !== i) {
      this.swap(i, smallest);
      this.sinkDown(smallest);
    }
  }

  get size(): number { return this.heap.length; }
  get min(): PrioritisedNotification | undefined { return this.heap[0]; }

  push(item: PrioritisedNotification): void {
    if (this.heap.length < this.capacity) {
      this.heap.push(item);
      this.bubbleUp(this.heap.length - 1);
    } else if (this.min && item.priorityScore > this.min.priorityScore) {
      this.heap[0] = item;
      this.sinkDown(0);
    }
  }

  /** Extract all elements sorted by descending priority score */
  toSortedDesc(): PrioritisedNotification[] {
    return [...this.heap].sort((a, b) => b.priorityScore - a.priorityScore);
  }
}

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * Compute the top-N priority notifications from a list.
 *
 * @param notifications - Full list of notifications from the AffordMed API
 * @param topN          - How many to return (default: 10)
 * @param typeFilter    - Optional: filter to only one notification type
 */
export function getTopNPriority(
  notifications: Notification[],
  topN: number = 10,
  typeFilter?: string
): PrioritisedNotification[] {
  Log("backend", "info", "domain",
    `computeTopN called — total=${notifications.length}, topN=${topN}, filter=${typeFilter ?? "all"}`
  );

  const filtered = typeFilter
    ? notifications.filter(n => n.Type === typeFilter)
    : notifications;

  const heap = new MinHeap(topN);

  for (const notification of filtered) {
    const scored: PrioritisedNotification = {
      ...notification,
      priorityScore: computePriorityScore(notification),
    };
    heap.push(scored);
  }

  const result = heap.toSortedDesc();

  Log("backend", "info", "domain",
    `computeTopN complete — returning ${result.length} prioritised notifications`
  );

  return result;
}
