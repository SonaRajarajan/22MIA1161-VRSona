/**
 * @file controller/notificationController.ts
 * @description Express route handlers for the notification API.
 *              Orchestrates repository calls, domain logic, and response formatting.
 */

import { Request, Response, NextFunction } from "express";
import { notificationRepository } from "../repository/notificationRepository";
import { getTopNPriority } from "../domain/priorityInbox";
import { Log } from "../middleware/logger";
import { ApiResponse, Notification, PrioritisedNotification } from "../domain/types";

// ─── GET /api/v1/notifications ────────────────────────────────────────────────

export async function getAllNotifications(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const typeFilter = req.query.type as string | undefined;

    Log("backend", "info", "controller",
      `GET /notifications — typeFilter=${typeFilter ?? "all"}, query=${JSON.stringify(req.query)}`
    );

    const notifications: Notification[] = await notificationRepository.fetchAll(typeFilter);

    // Client-side pagination (since AffordMed API returns all)
    const page = parseInt(req.query.page as string ?? "1", 10);
    const limit = Math.min(parseInt(req.query.limit as string ?? "20", 10), 100);
    const start = (page - 1) * limit;
    const paginated = notifications.slice(start, start + limit);

    Log("backend", "info", "controller",
      `GET /notifications responding — page=${page}, limit=${limit}, returning ${paginated.length}/${notifications.length}`
    );

    const response: ApiResponse<{
      notifications: Notification[];
      pagination: object;
    }> = {
      success: true,
      data: {
        notifications: paginated,
        pagination: {
          currentPage: page,
          totalPages: Math.ceil(notifications.length / limit),
          totalItems: notifications.length,
          limit,
        },
      },
    };

    res.status(200).json(response);
  } catch (err) {
    Log("backend", "error", "controller",
      `GET /notifications failed — ${err instanceof Error ? err.message : String(err)}`
    );
    next(err);
  }
}

// ─── GET /api/v1/notifications/priority ──────────────────────────────────────

export async function getPriorityNotifications(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const topN = parseInt(req.query.n as string ?? "10", 10);
    const typeFilter = req.query.type as string | undefined;

    Log("backend", "info", "controller",
      `GET /notifications/priority — topN=${topN}, typeFilter=${typeFilter ?? "all"}`
    );

    const allNotifications = await notificationRepository.fetchAll();
    const prioritised: PrioritisedNotification[] = getTopNPriority(
      allNotifications,
      topN,
      typeFilter
    );

    Log("backend", "info", "controller",
      `GET /notifications/priority responding — computed ${prioritised.length} priority notifications`
    );

    const response: ApiResponse<{
      topN: number;
      notifications: PrioritisedNotification[];
    }> = {
      success: true,
      data: {
        topN: prioritised.length,
        notifications: prioritised,
      },
    };

    res.status(200).json(response);
  } catch (err) {
    Log("backend", "error", "controller",
      `GET /notifications/priority failed — ${err instanceof Error ? err.message : String(err)}`
    );
    next(err);
  }
}
