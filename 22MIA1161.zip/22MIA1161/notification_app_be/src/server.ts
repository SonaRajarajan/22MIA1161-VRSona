/**
 * @file server.ts
 * @description Entry point — boots the Express server and binds to the configured port.
 */

import { createApp } from "./app";
import { config } from "./config";
import { Log } from "./middleware/logger";

const app = createApp();

const server = app.listen(config.server.port, () => {
  Log("backend", "info", "controller",
    `Notification API server started on port ${config.server.port} [${config.server.nodeEnv}]`
  );
  console.log(`\n🚀 Server running at http://localhost:${config.server.port}`);
  console.log(`📋 Health: http://localhost:${config.server.port}/health`);
  console.log(`🔔 Notifications: http://localhost:${config.server.port}/api/v1/notifications`);
  console.log(`⭐ Priority: http://localhost:${config.server.port}/api/v1/notifications/priority\n`);
});

// Graceful shutdown
process.on("SIGTERM", () => {
  Log("backend", "warn", "controller", "SIGTERM received — shutting down gracefully");
  server.close(() => {
    Log("backend", "info", "controller", "Server closed — process exiting");
    process.exit(0);
  });
});

process.on("uncaughtException", (err) => {
  Log("backend", "fatal", "handler", `Uncaught exception: ${err.message}`);
  process.exit(1);
});
