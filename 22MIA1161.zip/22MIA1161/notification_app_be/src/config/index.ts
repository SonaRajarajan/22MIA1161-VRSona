/**
 * @file config/index.ts
 * @description Centralised configuration loader. Reads environment variables
 *              and exports a typed config object consumed across the application.
 */

import dotenv from "dotenv";
import path from "path";

// Load .env from the backend root
dotenv.config({ path: path.resolve(__dirname, "../../.env") });

function requireEnv(key: string): string {
  const val = process.env[key];
  if (!val) {
    throw new Error(`[Config] Missing required environment variable: ${key}`);
  }
  return val;
}

export const config = {
  server: {
    port: parseInt(process.env.PORT ?? "5000", 10),
    nodeEnv: process.env.NODE_ENV ?? "development",
    allowedOrigin: process.env.ALLOWED_ORIGIN ?? "http://localhost:3000",
  },
  affordmed: {
    baseURL: requireEnv("AFFORDMED_BASE_URL"),
    accessToken: requireEnv("AFFORDMED_ACCESS_TOKEN"),
  },
} as const;
