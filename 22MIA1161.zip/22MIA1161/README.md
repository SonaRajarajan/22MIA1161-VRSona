# 22MIA1161

**Campus Hiring Evaluation — Full Stack Track**  
**Afford Medical Technologies Private Limited**

---

## Repository Structure

```
22MIA1161/
├── logging_middleware/              # Reusable logging package (Pre-Test Setup)
│   ├── src/index.ts                 # Core Log(stack, level, package, message) function
│   ├── package.json
│   └── tsconfig.json
│
├── notification_system_design.md   # Stages 1–6 design responses
│
├── notification_app_be/            # Backend — Node.js + Express + TypeScript
│   ├── src/
│   │   ├── config/index.ts          # Env config loader
│   │   ├── middleware/
│   │   │   ├── logger.ts            # Logger initialiser (wraps logging_middleware)
│   │   │   └── errorHandler.ts      # Global error + 404 handlers
│   │   ├── domain/
│   │   │   ├── types.ts             # Core domain types
│   │   │   └── priorityInbox.ts     # Stage 6 min-heap priority algorithm
│   │   ├── repository/
│   │   │   └── notificationRepository.ts  # AffordMed API client
│   │   ├── controller/
│   │   │   └── notificationController.ts  # Route handlers
│   │   ├── routes/
│   │   │   └── notificationRoutes.ts
│   │   ├── app.ts                   # Express app factory
│   │   └── server.ts                # Entry point
│   ├── .env.example
│   ├── package.json
│   └── tsconfig.json
│
└── notification_app_fe/            # Frontend — React + TypeScript + Material UI
    ├── src/
    │   ├── utils/
    │   │   ├── types.ts             # Shared TypeScript types
    │   │   └── logger.ts            # Frontend logging via backend proxy
    │   ├── hooks/
    │   │   ├── useNotifications.ts  # All notifications hook with pagination
    │   │   └── usePriorityNotifications.ts  # Priority inbox hook
    │   ├── components/
    │   │   └── NotificationCard.tsx # Reusable notification card component
    │   ├── pages/
    │   │   ├── AllNotificationsPage.tsx  # Page 1 — all notifications + filter
    │   │   └── PriorityInboxPage.tsx     # Page 2 — priority inbox + controls
    │   ├── App.tsx                  # Root component + MUI theme + routing
    │   └── index.tsx                # React entry point
    ├── public/index.html
    ├── package.json
    └── tsconfig.json
```

---

## Setup & Run

### 1. Logging Middleware
```bash
cd logging_middleware
npm install
npm run build
```

### 2. Backend
```bash
cd notification_app_be
npm install
cp .env.example .env
# Fill in AFFORDMED_ACCESS_TOKEN in .env
npm run dev          # development with hot-reload
# or
npm run build && npm start
```
Server runs at `http://localhost:5000`

### 3. Frontend
```bash
cd notification_app_fe
npm install
npm start            # runs at http://localhost:3000
```
The frontend proxies API calls to `http://localhost:5000` via the `proxy` field in package.json.

---

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/health` | Health check |
| `GET` | `/api/v1/notifications` | All notifications (with `?type=`, `?page=`, `?limit=`) |
| `GET` | `/api/v1/notifications/priority` | Top-N priority notifications (with `?n=`, `?type=`) |

---

## Design Highlights

- **Logging**: Every significant operation — API calls, errors, state changes, user interactions — is logged via the reusable `Log(stack, level, package, message)` middleware. No `console.log` as a substitute.
- **Priority Algorithm**: Min-heap of size N gives O(M log N) time — efficient even as notification counts grow.
- **Architecture**: Clean layered separation — config → middleware → repository → domain → controller → routes.
- **Frontend**: Material UI with custom theme, real-time read/unread state tracking in React, responsive layout, configurable top-N slider and type filters.
